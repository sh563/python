class Event:

    def __init__(self, model, purchase_price, sold_price, purchase_date, sold_date):
        self.model = model
        self.make = make
        self.purchase_price = purchase_price
        self.sold_price = sold_price
        self.purchase_date = purchase_date
        self.sold_date = sold_date


    def displayEvent(self):
        result = "The car Model " + str(self.model)
        result += " The price is :" + str(self.purchase_price)+"\n"
        result += "The sold Price is  : " + str(self.sold_price) + "\n"
        result += "The Date it is Purchased : " + str(self.purchase_date) + "\n"
        result += "The Date it was sold: " + str(self.sold_date) + "\n"
        result += "------------------------------------------------------------"
        return result

    def get_make(self):
     return self.make

    def set_make(self,make):
        self.make=make

    def get_model(self):
        return self.model
    def set_model(self,model):
        self.model=model

    def get_purchase_price(self):
        return self.purchase_price

    def set_purchase_price(self,purchase_price):
        self.purchase_price=purchase_price

    def get_sold_price(self):
        return self.sold_price

    def set_sold_price(self, sold_price):
        self.sold_price = sold_price

    def get_purchase_date(self):
        return self.purchase_date

    def set_purchase_date(self, purchase_date):
        self.purchase_date = purchase_date

    def get_sold_date(self):
        return self.sold_date

    def set_sold_date(self, sold_date):
        self.sold_date = sold_date

    def displayCar(self):
        result = "The car Model " + str(self.model)
        result += " The price is :" + str(self.purchase_price) + "\n"
        result += "The sold Price is  : " + str(self.sold_price) + "\n"
        result += "The Date it is Purchased : " + str(self.purchase_date) + "\n"
        result += "The Date it was sold: " + str(self.sold_date) + "\n"
        result += "------------------------------------------------------------"
        return result

class collection:
    def __init__(self):
        self.cars=[]

    def add_car(self,car):
        self.cars.append(car)
    def remove_car(self,car):
        for i in self.cars:
            if(self.cars[i].equalsTo(car)):
                self.cars.remove(self.cars[i])

    def modify_cars(self,car,newcar):
        for i in self.cars:
            if(self.cars[i].equalsto(car)):
                self.cars[i]=newcar

